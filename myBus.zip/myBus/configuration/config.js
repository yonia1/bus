/**
 * Created by Yoni on 04/10/2015.
 */
var config = {};
config.busUrl='http://interview.optibus.co:2503/';
module.exports = config;